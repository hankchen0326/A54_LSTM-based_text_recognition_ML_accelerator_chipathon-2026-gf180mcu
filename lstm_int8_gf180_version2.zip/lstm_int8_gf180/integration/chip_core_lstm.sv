`default_nettype none

// Adapter from the fixed Chipathon workshop padring contract to this LSTM top.
//
// Pad use:
//   input_in[0] = 0: config pads are inputs to the LSTM host interface.
//   input_in[0] = 1: config pads are outputs for status/readback.
//
// Input mode, bidir_in:
//   [0]     start
//   [1]     host_en
//   [2]     host_we
//   [9:3]   host_addr
//   [17:10] host_wdata
//   [19:18] unused
//
// Readback mode, bidir_out:
//   [0]     busy
//   [1]     done
//   [2]     host_rvalid
//   [10:3]  host_rdata
//   [17:11] fixed signature 7'h35
//   [19:18] fixed signature 2'b01
module chip_core #(
    parameter integer NUM_INPUT_PADS  = 1,
    parameter integer NUM_BIDIR_PADS  = 20,
    parameter integer NUM_ANALOG_PADS = 60,
    parameter [7:0]   LSTM_TIMESTEPS  = 8'd3
)(
`ifdef USE_POWER_PINS
    inout  wire VDD,
    inout  wire VSS,
`endif

    input  wire clk,
    input  wire rst_n,

    input  wire [NUM_INPUT_PADS-1:0] input_in,
    output wire [NUM_INPUT_PADS-1:0] input_pu,
    output wire [NUM_INPUT_PADS-1:0] input_pd,

    input  wire [NUM_BIDIR_PADS-1:0] bidir_in,
    output wire [NUM_BIDIR_PADS-1:0] bidir_out,
    output wire [NUM_BIDIR_PADS-1:0] bidir_oe,
    output wire [NUM_BIDIR_PADS-1:0] bidir_cs,
    output wire [NUM_BIDIR_PADS-1:0] bidir_sl,
    output wire [NUM_BIDIR_PADS-1:0] bidir_ie,
    output wire [NUM_BIDIR_PADS-1:0] bidir_pu,
    output wire [NUM_BIDIR_PADS-1:0] bidir_pd,

    inout  wire [NUM_ANALOG_PADS-1:0] analog
);
    wire readback_mode;
    wire lstm_busy;
    wire lstm_done;
    wire [7:0] lstm_host_rdata;
    wire lstm_host_rvalid;
    wire [19:0] readback20;

    assign readback_mode = input_in[0];

    assign input_pu = {NUM_INPUT_PADS{1'b0}};
    assign input_pd = {NUM_INPUT_PADS{1'b0}};

    assign bidir_oe = {NUM_BIDIR_PADS{readback_mode}};
    assign bidir_cs = {NUM_BIDIR_PADS{1'b0}};
    assign bidir_sl = {NUM_BIDIR_PADS{1'b0}};
    assign bidir_ie = ~bidir_oe;
    assign bidir_pu = {NUM_BIDIR_PADS{1'b0}};
    assign bidir_pd = {NUM_BIDIR_PADS{1'b0}};

    assign readback20 = {
        2'b01,
        7'h35,
        lstm_host_rdata,
        lstm_host_rvalid,
        lstm_done,
        lstm_busy
    };
    assign bidir_out = readback_mode ? readback20[NUM_BIDIR_PADS-1:0]
                                     : {NUM_BIDIR_PADS{1'b0}};

    lstm_top u_lstm (
        .clk         (clk),
        .rst_n       (rst_n),

        .start       ((!readback_mode) & bidir_in[0]),
        .timesteps   (LSTM_TIMESTEPS),
        .busy        (lstm_busy),
        .done        (lstm_done),

        .host_en     ((!readback_mode) & bidir_in[1]),
        .host_we     (bidir_in[2]),
        .host_addr   (bidir_in[9:3]),
        .host_wdata  (bidir_in[17:10]),
        .host_rdata  (lstm_host_rdata),
        .host_rvalid (lstm_host_rvalid),

`ifdef USE_POWER_PINS
        .VDD         (VDD),
        .VSS         (VSS)
`else
        .VDD         (),
        .VSS         ()
`endif
    );

endmodule

`default_nettype wire
