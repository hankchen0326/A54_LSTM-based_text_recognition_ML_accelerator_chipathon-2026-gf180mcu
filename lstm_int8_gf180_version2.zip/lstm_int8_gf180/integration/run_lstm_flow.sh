#!/usr/bin/env bash
set -uo pipefail

cd /foss/designs/chipathon_padring/template || exit 98
: > lstm_flow.log
exec >> lstm_flow.log 2>&1

rm -f lstm_flow.done lstm_flow.exit

echo "=== LSTM LibreLane flow started at $(date) ==="
echo "Working directory: $(pwd)"
echo

source /foss/tools/sak/sak-pdk-script.sh gf180mcuD gf180mcu_fd_sc_mcu7t5v0
source_rc=$?
if [ "${source_rc}" -ne 0 ]; then
    echo "sak-pdk-script.sh failed with rc=${source_rc}"
    echo "${source_rc}" > lstm_flow.exit
    date > lstm_flow.done
    exit "${source_rc}"
fi

make librelane SLOT=workshop PDK=gf180mcuD PDK_ROOT=/foss/designs/chipathon_padring/template/gf180mcu
flow_rc=$?

echo
echo "=== LSTM LibreLane flow finished with rc=${flow_rc} at $(date) ==="
echo "${flow_rc}" > lstm_flow.exit
date > lstm_flow.done
exit "${flow_rc}"
