rtl/mul8.v
rtl/act_lut.v
rtl/tanh8.v
rtl/gate_regs.v
rtl/core.v
rtl/sram_wrap.v
rtl/top.v
