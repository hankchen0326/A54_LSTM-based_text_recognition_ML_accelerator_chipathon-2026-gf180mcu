`timescale 1ns/1ps

module tb_lstm_top;
    localparam integer CASE_TIMESTEPS = 3;
    localparam [4:0] ST_SAVE_GATE = 5'd11;
    localparam [4:0] ST_MUL_FC    = 5'd12;
    localparam [4:0] ST_MUL_OH    = 5'd15;
    localparam [4:0] ST_WRITE_H   = 5'd17;

    reg         clk;
    reg         rst_n;
    reg         start;
    reg  [7:0]  timesteps;
    wire        busy;
    wire        done;
    reg         host_en;
    reg         host_we;
    reg  [6:0]  host_addr;
    reg  [7:0]  host_wdata;
    wire [7:0]  host_rdata;
    wire        host_rvalid;
    wire        VDD;
    wire        VSS;

    reg  [7:0]  init_mem [0:127];
    reg  [23:0] expected_acc [0:11];
    reg  [7:0]  expected_gate [0:11];
    reg  [7:0]  expected_c_next [0:2];
    reg  [7:0]  expected_h_next [0:2];

    integer addr;
    integer errors;
    integer gate_index;
    integer timestep_index;

    assign VDD = 1'b1;
    assign VSS = 1'b0;

    lstm_top u_dut (
        .clk         (clk),
        .rst_n       (rst_n),
        .start       (start),
        .timesteps   (timesteps),
        .busy        (busy),
        .done        (done),
        .host_en     (host_en),
        .host_we     (host_we),
        .host_addr   (host_addr),
        .host_wdata  (host_wdata),
        .host_rdata  (host_rdata),
        .host_rvalid (host_rvalid),
        .VDD         (VDD),
        .VSS         (VSS)
    );

    initial begin
        clk = 1'b0;
        // The foundry SRAM model includes timing checks; use a relaxed clock
        // period so host writes and core accesses satisfy the macro limits.
        forever #30 clk = ~clk;
    end

    task host_write;
        input [6:0] addr_i;
        input [7:0] data_i;
        begin
            @(negedge clk);
            host_en    <= 1'b1;
            host_we    <= 1'b1;
            host_addr  <= addr_i;
            host_wdata <= data_i;
            @(posedge clk);
            @(negedge clk);
            host_en    <= 1'b0;
            host_we    <= 1'b0;
            host_addr  <= 7'd0;
            host_wdata <= 8'd0;
        end
    endtask

    task check_signed24;
        input [255:0] label;
        input signed [23:0] got_value;
        input signed [23:0] exp_value;
        begin
            if (got_value !== exp_value) begin
                $display("Mismatch %0s: got %0d expected %0d", label, got_value, exp_value);
                errors = errors + 1;
            end
        end
    endtask

    task check_signed8;
        input [255:0] label;
        input signed [7:0] got_value;
        input signed [7:0] exp_value;
        begin
            if (got_value !== exp_value) begin
                $display("Mismatch %0s: got %0d expected %0d", label, got_value, exp_value);
                errors = errors + 1;
            end
        end
    endtask

    always @(posedge clk) begin
        if (rst_n && busy) begin
            if (u_dut.u_core.state == ST_SAVE_GATE) begin
                check_signed24("acc",
                               u_dut.u_core.acc,
                               $signed(expected_acc[gate_index]));
                check_signed8("gate_value",
                              u_dut.u_core.gate_value_from_activation,
                              $signed(expected_gate[gate_index]));
                gate_index <= gate_index + 1;
            end

            if (u_dut.u_core.state == ST_MUL_FC) begin
                check_signed8("gate_f",
                              u_dut.u_core.gate_f,
                              $signed(expected_gate[timestep_index * 4 + 0]));
                check_signed8("gate_i",
                              u_dut.u_core.gate_i,
                              $signed(expected_gate[timestep_index * 4 + 1]));
                check_signed8("gate_g",
                              u_dut.u_core.gate_g,
                              $signed(expected_gate[timestep_index * 4 + 2]));
                check_signed8("gate_o",
                              u_dut.u_core.gate_o,
                              $signed(expected_gate[timestep_index * 4 + 3]));
            end

            if (u_dut.u_core.state == ST_MUL_OH) begin
                check_signed8("c_next",
                              u_dut.u_core.c_next,
                              $signed(expected_c_next[timestep_index]));
            end

            if (u_dut.u_core.state == ST_WRITE_H) begin
                check_signed8("h_state",
                              u_dut.u_core.h_state,
                              $signed(expected_h_next[timestep_index]));
                timestep_index <= timestep_index + 1;
            end
        end
    end

    initial begin
        $readmemh("vectors/testcase_init.hex", init_mem);
        $readmemh("vectors/trace_acc_q214.hex", expected_acc);
        $readmemh("vectors/trace_gate_q17.hex", expected_gate);
        $readmemh("vectors/trace_c_next_q17.hex", expected_c_next);
        $readmemh("vectors/trace_h_next_q17.hex", expected_h_next);

        rst_n      = 1'b0;
        start      = 1'b0;
        timesteps  = CASE_TIMESTEPS[7:0];
        host_en    = 1'b0;
        host_we    = 1'b0;
        host_addr  = 7'd0;
        host_wdata = 8'd0;
        errors     = 0;
        gate_index = 0;
        timestep_index = 0;

        repeat (4) @(posedge clk);
        rst_n = 1'b1;

        for (addr = 0; addr < 128; addr = addr + 1)
            host_write(addr[6:0], init_mem[addr]);

        @(negedge clk);
        start <= 1'b1;
        @(posedge clk);
        @(negedge clk);
        start <= 1'b0;

        @(posedge done);
        repeat (2) @(posedge clk);

        if (errors != 0) begin
            $display("FAIL: %0d LSTM trace mismatches", errors);
            $fatal(1);
        end

        $display("PASS: LSTM acc/gates/c_next/h_state match golden trace");
        $display("Output h: %0d %0d %0d",
                 $signed(expected_h_next[0]),
                 $signed(expected_h_next[1]),
                 $signed(expected_h_next[2]));
        $display("Output c: %0d %0d %0d",
                 $signed(expected_c_next[0]),
                 $signed(expected_c_next[1]),
                 $signed(expected_c_next[2]));
        $finish;
    end
endmodule
