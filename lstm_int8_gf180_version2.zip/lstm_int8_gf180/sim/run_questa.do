transcript on
set script_dir [file dirname [file normalize [info script]]]
set project_dir [file dirname $script_dir]
cd $project_dir
if {![file exists work]} {
    vlib work
}
vmap work work
vlog -f sim/files_sim.f
vsim -voptargs=+acc tb_lstm_top -do "run -all"
