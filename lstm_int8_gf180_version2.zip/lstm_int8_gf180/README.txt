Clean INT8 LSTM MVP for GF180 SRAM macro
========================================

Main module:
    lstm_top

Suggested layout:
    rtl/      design RTL and wrappers
    sim/      simulation-only sources and batch scripts
    vectors/  generated test inputs, traces, and summaries
    scripts/  helper generators
    README.txt, files_rtl.f remain at the project root as entry points

Files:
    rtl/top.v            - Small top-level wrapper. Connects host, core, and SRAM.
    rtl/core.v           - LSTM FSM and datapath control.
    rtl/gate_regs.v      - Stores f, i, g, o gate values.
    rtl/mul8.v           - Combinational signed INT8 x INT8 multiplier, no Verilog '*'.
    rtl/act_lut.v        - 32-entry sigmoid/tanh gate activation LUT.
    rtl/tanh8.v          - Tanh LUT for cell-state output tanh(c_next).
    rtl/sram_wrap.v      - GF180 128x8 SRAM macro wrapper.
    rtl/gf180mcu_fd_ip_sram__sram128x8m8wm1.v
                         - GF180 foundry SRAM simulation model used by Questa.
    sim/tb_lstm_top.v    - Functional trace-based testbench.
    scripts/gen_golden_case.py - Generates vectors/ contents.

Use the foundry SRAM model only for simulation. For GF180 PNR, use the real
macro views from the PDK for the macro named:
    gf180mcu_fd_ip_sram__sram128x8m8wm1

Data format:
    signed Q1.7 fixed-point stored directly in one SRAM byte.
    Example: 8'sd64 = +0.5, 8'sd-64 = -0.5.

LSTM size:
    input y = [y0,y1,y2,y3,y4,y5,y6,y7]
    one hidden state h
    one cell state c
    vector = [y0,y1,y2,y3,y4,y5,y6,y7,h]

Gate order:
    f, i, g, o

Gate equations:
    f = sigmoid(W_f dot vector + b_f)
    i = sigmoid(W_i dot vector + b_i)
    g = tanh   (W_g dot vector + b_g)
    o = sigmoid(W_o dot vector + b_o)

State update:
    c_next = sat8((f*c_old >> FRAC_BITS) + (i*g >> FRAC_BITS))
    h_next = sat8((o*tanh(c_next)) >> FRAC_BITS)

Default memory map, 128x8 SRAM:
    0   - 35   weights: f,i,g,o, 9 weights per gate
    40  - 43   bias:    f,i,g,o
    48  - 79   inputs:  8 bytes per timestep, up to 4 timesteps
    88         initial h
    89         initial c
    96  - 99   output h
    104 - 107  output c
    127        signature/debug byte

Parameters in top/core:
    ACC_WIDTH        = accumulator width, default 24
    FRAC_BITS        = fixed-point fractional bits, default 7
    GATE_INPUT_SHIFT = pre-activation LUT address shift, default 10

Host interface:
    host_en     = active-high host SRAM access request
    host_we     = 1 write / 0 read
    host_addr   = SRAM address
    host_wdata  = host write data
    host_rdata  = host read data
    host_rvalid = high for one cycle when a host read completes

Notes:
    The RTL uses a synchronous single-port SRAM model, so host reads complete
    one clock after host_en is asserted with host_we=0.
    The LSTM datapath is fixed-point, not integer-only: multiply results are
    shifted by FRAC_BITS to preserve Q1.7 semantics.

Synthesis file list:
    files_rtl.f

Simulation file list:
    sim/files_sim.f

Generate the bundled golden-model testcase:
    C:\Users\new12\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe scripts\gen_golden_case.py
    The generated vectors/testcase_summary.json includes both dequantized float values
    and raw Q1.7 integers for the same vectors.
    It also emits functional trace files:
        vectors/trace_acc_q214.hex
        vectors/trace_gate_q17.hex
        vectors/trace_c_next_q17.hex
        vectors/trace_h_next_q17.hex

Run the QuestaSim batch check:
    vsim -c -do sim/run_questa.do
    This check compares internal LSTM math, not full SRAM contents.
