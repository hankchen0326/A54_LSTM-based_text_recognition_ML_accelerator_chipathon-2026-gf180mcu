create_clock [get_ports clk] -name core_clk -period 100.0
set_input_delay  5.0 -clock [get_clocks core_clk] [remove_from_collection [all_inputs] [get_ports clk]]
set_output_delay 5.0 -clock [get_clocks core_clk] [all_outputs]

# Reset is asynchronous in RTL; keep it out of timing closure.
set_false_path -from [get_ports rst_n]
set_false_path -to   [get_ports rst_n]
