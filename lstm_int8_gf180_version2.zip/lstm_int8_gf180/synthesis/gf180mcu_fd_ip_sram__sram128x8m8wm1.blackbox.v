`timescale 1ns/1ps

// Synthesis blackbox stub for the GF180 SRAM macro.
// Use the real .lib/.lef/.gds views from the PDK in the backend flow.
(* blackbox *)
module gf180mcu_fd_ip_sram__sram128x8m8wm1 (
    input  wire       CLK,
    input  wire       CEN,
    input  wire       GWEN,
    input  wire [7:0] WEN,
    input  wire [6:0] A,
    input  wire [7:0] D,
    output wire [7:0] Q,
    inout  wire       VDD,
    inout  wire       VSS
);
endmodule
