Synthesis Bundle For The Chipathon VM
=====================================

What this folder is for:
    This folder contains the extra files needed to push the current RTL into
    synthesis / LibreLane with the GF180 SRAM kept as a hard macro.

What you should copy together:
    1. this synthesis/ folder
    2. the rtl/ folder next to it

Expected layout after copy:
    <project>/
        rtl/
        synthesis/

Files in this folder:
    gf180mcu_fd_ip_sram__sram128x8m8wm1.blackbox.v
        - synthesis-only blackbox stub for the SRAM macro
    files_synth.f
        - synthesis RTL list; points to ../rtl plus the blackbox
    constraints.sdc
        - basic 10 MHz clock and simple IO timing assumptions
    macro_views.txt
        - exact PDK macro paths to use in the VM
    librelane_config.yaml
        - starting template for a Chipathon / LibreLane run

Important:
    Do not use ../rtl/gf180mcu_fd_ip_sram__sram128x8m8wm1.v in synthesis.
    That file is the foundry simulation model with timing checks, not the
    synthesis blackbox.

Why the blackbox is needed:
    In synthesis, the SRAM must stay as an instantiated hard macro. The tools
    should not try to infer or map its internal behavior into standard cells.

Top module:
    lstm_top

Clock:
    clk
    Current template period = 100 ns (10 MHz)

Why start at 10 MHz:
    The goal here is to get a clean first synthesis pass with the SRAM macro
    connected correctly. You can tighten the clock later after the first area
    and timing report.

Current design behavior:
    weights / bias / input / h0 / c0 are loaded into SRAM by the host interface
    before start is asserted. This is intentional. The synthesis flow does not
    "burn" hex contents into the SRAM macro.

Suggested VM-side first checks:
    1. confirm the PDK macro files exist at the paths listed in macro_views.txt
    2. confirm the flow sees lstm_top as the top module
    3. run synthesis only first
    4. inspect whether the SRAM macro is preserved as a macro instance

If you need a pure synthesis-only sanity pass before full LibreLane:
    Use files_synth.f + constraints.sdc + the blackbox stub as the minimal
    source package.
