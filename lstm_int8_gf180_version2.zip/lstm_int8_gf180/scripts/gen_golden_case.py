import json
import random
from pathlib import Path

FRAC_BITS = 7
Q_SCALE = 1 << FRAC_BITS
DATASET_SEED = 1000
W_BASE = 0
B_BASE = 40
X_BASE = 48
H0_ADDR = 88
C0_ADDR = 89
OH_BASE = 96
OC_BASE = 104
SIG_ADDR = 127
TIMESTEPS = 3

GATE_INPUT_SHIFT = 10
TANH_STATE_SHIFT = 3
TANH_GATE_LUT = [-97, -94, -90, -86, -81, -76, -71, -65, -59, -53, -46, -39, -31, -24, -16, -8, 0, 8, 16, 24, 31, 39, 46, 53, 59, 65, 71, 76, 81, 86, 90, 94]
SIGMOID_GATE_LUT = [34, 36, 38, 39, 41, 43, 45, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66, 68, 70, 72, 74, 76, 78, 80, 82, 83, 85, 87, 89, 90, 92]
TANH_STATE_LUT = [-97, -93, -89, -85, -81, -76, -70, -65, -59, -52, -46, -38, -31, -24, -16, -8, 0, 8, 16, 24, 31, 38, 46, 52, 59, 65, 70, 76, 81, 85, 89, 93]


def sat_s8(value: int) -> int:
    return max(-128, min(127, value))


def to_u8(value: int) -> int:
    return value & 0xFF


def q17(value: float) -> int:
    return sat_s8(int(round(value * Q_SCALE)))


def deq17(value: int) -> float:
    return value / float(Q_SCALE)


def sample_q17(rng: random.Random, low: float, high: float) -> int:
    low_q = max(-128, int(round(low * Q_SCALE)))
    high_q = min(127, int(round(high * Q_SCALE)))
    return rng.randint(low_q, high_q)


def weight_addr(gate_id: int, index: int) -> int:
    return W_BASE + gate_id * 9 + index


def input_addr(timestep: int, index: int) -> int:
    return X_BASE + timestep * 8 + index


def gate_activation(acc: int, is_tanh: bool) -> int:
    index = max(0, min(31, (acc >> GATE_INPUT_SHIFT) + 16))
    if is_tanh:
        return TANH_GATE_LUT[index]
    return SIGMOID_GATE_LUT[index]


def gate_lut_index(acc: int) -> int:
    return max(0, min(31, (acc >> GATE_INPUT_SHIFT) + 16))


def tanh_state(value: int) -> int:
    index = max(0, min(31, (value >> TANH_STATE_SHIFT) + 16))
    return TANH_STATE_LUT[index]


def s8_hex(value: int) -> str:
    return f"0x{to_u8(value):02X}"


def s24_hex(value: int) -> str:
    return f"0x{(value & 0xFFFFFF):06X}"


def build_case():
    for case_seed in range(DATASET_SEED, DATASET_SEED + 256):
        rng = random.Random(case_seed)
        weights = [[sample_q17(rng, -0.75, 0.75) for _ in range(9)] for _ in range(4)]
        biases = [sample_q17(rng, -0.10, 0.10) for _ in range(4)]
        inputs = [[sample_q17(rng, -0.50, 0.50) for _ in range(8)] for _ in range(TIMESTEPS)]
        h0 = sample_q17(rng, -0.20, 0.20)
        c0 = sample_q17(rng, -0.20, 0.20)

        mem = [0] * 128
        for gate_id in range(4):
            for idx, value in enumerate(weights[gate_id]):
                mem[weight_addr(gate_id, idx)] = to_u8(value)

        for gate_id, value in enumerate(biases):
            mem[B_BASE + gate_id] = to_u8(value)

        for timestep in range(TIMESTEPS):
            for idx, value in enumerate(inputs[timestep]):
                mem[input_addr(timestep, idx)] = to_u8(value)

        mem[H0_ADDR] = to_u8(h0)
        mem[C0_ADDR] = to_u8(c0)

        golden = list(mem)
        h_state = h0
        c_state = c0

        out_h = []
        out_c = []
        acc_trace = []
        gate_trace = []
        timestep_trace = []

        for timestep in range(TIMESTEPS):
            vector = inputs[timestep] + [h_state]
            gates = []

            for gate_id in range(4):
                acc = biases[gate_id] << FRAC_BITS
                products = []
                for idx in range(9):
                    product = weights[gate_id][idx] * vector[idx]
                    products.append(product)
                    acc += product
                gate_value = gate_activation(acc, gate_id == 2)
                acc_trace.append(acc)
                gate_trace.append(gate_value)
                gates.append(gate_value)

            gate_f, gate_i, gate_g, gate_o = gates
            fc_term = (gate_f * c_state) >> FRAC_BITS
            ig_term = (gate_i * gate_g) >> FRAC_BITS
            c_next = sat_s8(fc_term + ig_term)
            tanh_c = tanh_state(c_next)
            oh_term = (gate_o * tanh_c) >> FRAC_BITS
            h_next = sat_s8(oh_term)
            gate_details = []
            for gate_id in range(4):
                acc = biases[gate_id] << FRAC_BITS
                products = []
                for idx in range(9):
                    product = weights[gate_id][idx] * vector[idx]
                    products.append(product)
                    acc += product
                gate_value = gate_activation(acc, gate_id == 2)
                gate_details.append(
                    {
                        "gate_name": ["f", "i", "g", "o"][gate_id],
                        "bias_q17": biases[gate_id],
                        "bias_float": deq17(biases[gate_id]),
                        "weights_q17": weights[gate_id],
                        "weights_float": float_vector(weights[gate_id]),
                        "products_q214": products,
                        "acc_q214": acc,
                        "scaled_q_index": (acc >> GATE_INPUT_SHIFT),
                        "lut_index": gate_lut_index(acc),
                        "gate_q17": gate_value,
                        "gate_float": deq17(gate_value),
                    }
                )
            timestep_trace.append(
                {
                    "timestep": timestep,
                    "h_prev_q17": h_state,
                    "h_prev_float": deq17(h_state),
                    "c_prev_q17": c_state,
                    "c_prev_float": deq17(c_state),
                    "vector_q17": vector,
                    "vector_float": float_vector(vector),
                    "acc_q214": acc_trace[-4:],
                    "gate_q17": gates,
                    "gate_float": float_vector(gates),
                    "gate_details": gate_details,
                    "fc_term_q17": fc_term,
                    "fc_term_float": deq17(fc_term),
                    "ig_term_q17": ig_term,
                    "ig_term_float": deq17(ig_term),
                    "c_next_q17": c_next,
                    "c_next_float": deq17(c_next),
                    "tanh_c_q17": tanh_c,
                    "tanh_c_float": deq17(tanh_c),
                    "oh_term_q17": oh_term,
                    "oh_term_float": deq17(oh_term),
                    "h_next_q17": h_next,
                    "h_next_float": deq17(h_next),
                }
            )

            h_state = h_next
            c_state = c_next
            out_h.append(h_state)
            out_c.append(c_state)
            golden[OH_BASE + timestep] = to_u8(h_state)
            golden[OC_BASE + timestep] = to_u8(c_state)

        if out_h[-1] == 0 or out_c[-1] == 0:
            continue

        golden[SIG_ADDR] = to_u8(0xA5 ^ to_u8(h_state) ^ to_u8(c_state))

        return {
            "weights": weights,
            "biases": biases,
            "inputs": inputs,
            "h0": h0,
            "c0": c0,
            "out_h": out_h,
            "out_c": out_c,
            "acc_trace": acc_trace,
            "gate_trace": gate_trace,
            "timestep_trace": timestep_trace,
            "init_mem": mem,
            "expected_mem": golden,
            "dataset_seed_used": case_seed,
        }

    raise RuntimeError("Could not find a non-degenerate testcase in the seed search window.")


def write_hex(path: Path, values):
    path.write_text("\n".join(f"{value:02x}" for value in values) + "\n", encoding="ascii")


def write_hex_width(path: Path, values, width: int):
    mask = (1 << width) - 1
    digits = (width + 3) // 4
    path.write_text("\n".join(f"{(value & mask):0{digits}x}" for value in values) + "\n", encoding="ascii")


def float_matrix(values):
    return [[deq17(value) for value in row] for row in values]


def float_vector(values):
    return [deq17(value) for value in values]


def write_report(path: Path, case, summary):
    lines = []
    lines.append("LSTM Testcase Detailed Report")
    lines.append("============================")
    lines.append("")
    lines.append(f"Format: {summary['format']} (scale={summary['scale']})")
    lines.append(f"Timesteps: {summary['timesteps']}")
    lines.append("")
    lines.append("Fixed-Point Notes")
    lines.append("-----------------")
    lines.append("Stored 8-bit values use signed Q1.7 fixed point.")
    lines.append("Interpretation:")
    lines.append("  real_value = signed_integer / 2^7 = signed_integer / 128")
    lines.append("")
    lines.append("Examples:")
    lines.append("  0x40 ->  64 ->  64/128 =  0.5")
    lines.append("  0xE7 -> -25 -> -25/128 = -0.1953125")
    lines.append("")
    lines.append("When two Q1.7 values are multiplied:")
    lines.append("  (a/128) * (b/128) = (a*b) / 2^14")
    lines.append("So the raw multiplier result is on a wider scale (often described as Q2.14).")
    lines.append("To bring the result back near Q1.7 scale, the RTL shifts right by 7:")
    lines.append("  (a*b) >> 7")
    lines.append("")
    lines.append("Bias alignment in the MAC accumulator is done with:")
    lines.append("  bias << 7")
    lines.append("This moves a Q1.7 bias onto the same scale used by the sum of products.")
    lines.append("")
    lines.append("Current Testcase Activation Mapping")
    lines.append("-----------------------------------")
    lines.append("Gate LUT input range is [-1.0, 1.0) sampled every 1/16.")
    lines.append("For gate g (tanh LUT):")
    lines.append(f"  scaled = acc >>> {GATE_INPUT_SHIFT}")
    lines.append("  index  = clamp(scaled + 16, 0, 31)")
    lines.append("For gates f/i/o (sigmoid LUT):")
    lines.append(f"  scaled = acc >>> {GATE_INPUT_SHIFT}")
    lines.append("  index  = clamp(scaled + 16, 0, 31)")
    lines.append("")
    for t_index, timestep in enumerate(summary["timestep_trace"]):
        lines.append(f"timestep {t_index}:")
        for gate in timestep["gate_details"]:
            if gate["gate_name"] == "g":
                lines.append(
                    f"  gate {gate['gate_name']} (tanh LUT): acc={s24_hex(gate['acc_q214'])} ({gate['acc_q214']})"
                    f", scaled=(acc>>{GATE_INPUT_SHIFT})={gate['scaled_q_index']}, index={gate['lut_index']},"
                    f" out={s8_hex(gate['gate_q17'])} ({gate['gate_q17']}, {gate['gate_float']:.7f})"
                )
            else:
                lines.append(
                    f"  gate {gate['gate_name']} (sigmoid LUT): acc={s24_hex(gate['acc_q214'])} ({gate['acc_q214']})"
                    f", scaled=(acc>>{GATE_INPUT_SHIFT})={gate['scaled_q_index']}, index={gate['lut_index']},"
                    f" out={s8_hex(gate['gate_q17'])} ({gate['gate_q17']}, {gate['gate_float']:.7f})"
                )
        lines.append("")

    lines.append("Initial State")
    lines.append("-------------")
    lines.append(
        f"h0 = {s8_hex(case['h0'])} = {case['h0']} -> {deq17(case['h0']):.7f}"
    )
    lines.append(
        f"c0 = {s8_hex(case['c0'])} = {case['c0']} -> {deq17(case['c0']):.7f}"
    )
    lines.append("")
    lines.append("Input SRAM Image Highlights")
    lines.append("---------------------------")
    lines.append("Address ranges:")
    lines.append("  0..35   weights")
    lines.append("  40..43  biases")
    lines.append("  48..71  input sequence (3 timesteps x 8 values)")
    lines.append("  88      h0")
    lines.append("  89      c0")
    lines.append("")

    for t_index, timestep in enumerate(summary["timestep_trace"]):
        lines.append(f"Timestep {t_index}")
        lines.append("-" * 10)
        lines.append(
            f"h_prev = {s8_hex(timestep['h_prev_q17'])} = {timestep['h_prev_q17']} -> {timestep['h_prev_float']:.7f}"
        )
        lines.append(
            f"c_prev = {s8_hex(timestep['c_prev_q17'])} = {timestep['c_prev_q17']} -> {timestep['c_prev_float']:.7f}"
        )
        lines.append("input vector [y0..y7,h_prev]:")
        for i, value in enumerate(timestep["vector_q17"]):
            label = f"y{i}" if i < 8 else "h_prev"
            lines.append(
                f"  {label:<6} {s8_hex(value):>6}  {value:>4}  {timestep['vector_float'][i]:>10.7f}"
            )
        lines.append("")

        for gate in timestep["gate_details"]:
            lines.append(f"gate {gate['gate_name']}:")
            lines.append(
                f"  bias = {s8_hex(gate['bias_q17'])} = {gate['bias_q17']} -> {gate['bias_float']:.7f}"
            )
            product_terms = []
            for i, (w, x, p) in enumerate(
                zip(gate["weights_q17"], timestep["vector_q17"], gate["products_q214"])
            ):
                name = f"w{i}*v{i}"
                product_terms.append((i, w, x, p))
                lines.append(
                    f"  {name:<8} w={s8_hex(w)} ({w:>4}, {deq17(w):>10.7f})"
                    f"  v={s8_hex(x)} ({x:>4}, {deq17(x):>10.7f})"
                    f"  p={p:>6}"
                )
            lines.append("  acc formula:")
            lines.append(f"    acc = ({gate['bias_q17']} << 7)")
            for i, w, x, p in product_terms:
                lines.append(f"        + ({w} * {x})    -> term{i} = {p}")
            lines.append(
                f"    acc result = {s24_hex(gate['acc_q214'])} = {gate['acc_q214']}"
            )
            lines.append(
                f"  gate out   = {s8_hex(gate['gate_q17'])} = {gate['gate_q17']} -> {gate['gate_float']:.7f}"
            )
            lines.append("")

        lines.append("state update:")
        lines.append(
            f"  fc_term = (f * c_prev) >> 7 = {timestep['fc_term_q17']} -> {timestep['fc_term_float']:.7f}"
        )
        lines.append(
            f"  ig_term = (i * g) >> 7      = {timestep['ig_term_q17']} -> {timestep['ig_term_float']:.7f}"
        )
        lines.append(
            f"  c_next  = sat8(fc_term + ig_term) = {s8_hex(timestep['c_next_q17'])} = {timestep['c_next_q17']} -> {timestep['c_next_float']:.7f}"
        )
        lines.append(
            f"  tanh(c_next) LUT = {s8_hex(timestep['tanh_c_q17'])} = {timestep['tanh_c_q17']} -> {timestep['tanh_c_float']:.7f}"
        )
        lines.append(
            f"  oh_term = (o * tanh(c_next)) >> 7 = {timestep['oh_term_q17']} -> {timestep['oh_term_float']:.7f}"
        )
        lines.append(
            f"  h_next  = sat8(oh_term) = {s8_hex(timestep['h_next_q17'])} = {timestep['h_next_q17']} -> {timestep['h_next_float']:.7f}"
        )
        lines.append("")

    lines.append("Final Expected Outputs")
    lines.append("----------------------")
    for i, (h, c) in enumerate(zip(summary["out_h_q17"], summary["out_c_q17"])):
        lines.append(
            f"t={i}: h_next={s8_hex(h)} ({h}, {deq17(h):.7f}), "
            f"c_next={s8_hex(c)} ({c}, {deq17(c):.7f})"
        )

    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def main():
    case = build_case()
    project_root = Path(__file__).resolve().parent.parent
    vectors_dir = project_root / "vectors"
    vectors_dir.mkdir(exist_ok=True)
    write_hex(vectors_dir / "testcase_init.hex", case["init_mem"])
    write_hex_width(vectors_dir / "trace_acc_q214.hex", case["acc_trace"], 24)
    write_hex(vectors_dir / "trace_gate_q17.hex", [to_u8(value) for value in case["gate_trace"]])
    write_hex(vectors_dir / "trace_c_next_q17.hex", [to_u8(value) for value in case["out_c"]])
    write_hex(vectors_dir / "trace_h_next_q17.hex", [to_u8(value) for value in case["out_h"]])

    summary = {
        "format": "Q1.7",
        "scale": Q_SCALE,
        "dataset_seed": DATASET_SEED,
        "notes": [
            "All values are exact Q1.7 fractions, not free-form floating point.",
            "The RTL consumes the quantized integers; float views below are dequantized by dividing by 128.",
            "Ranges were chosen to look like normalized LSTM weights, biases, and activations."
        ],
        "timesteps": TIMESTEPS,
        "weights_q17": case["weights"],
        "weights_float": float_matrix(case["weights"]),
        "biases_q17": case["biases"],
        "biases_float": float_vector(case["biases"]),
        "inputs_q17": case["inputs"],
        "inputs_float": float_matrix(case["inputs"]),
        "h0_q17": case["h0"],
        "h0_float": deq17(case["h0"]),
        "c0_q17": case["c0"],
        "c0_float": deq17(case["c0"]),
        "out_h_q17": case["out_h"],
        "out_h_float": float_vector(case["out_h"]),
        "out_c_q17": case["out_c"],
        "out_c_float": float_vector(case["out_c"]),
        "signature_hex": f"0x{case['expected_mem'][SIG_ADDR]:02x}",
        "timestep_trace": case["timestep_trace"],
    }
    (vectors_dir / "testcase_summary.json").write_text(json.dumps(summary, indent=2), encoding="ascii")
    write_report(vectors_dir / "testcase_report.txt", case, summary)


if __name__ == "__main__":
    main()
