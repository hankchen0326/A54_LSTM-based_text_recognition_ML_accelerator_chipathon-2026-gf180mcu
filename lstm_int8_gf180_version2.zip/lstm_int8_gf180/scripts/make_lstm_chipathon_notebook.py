from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "03_rtl2gds_chipathon_lstm.ipynb"


def markdown(source: str) -> dict:
    return {"cell_type": "markdown", "metadata": {}, "source": source.splitlines(keepends=True)}


def code(source: str) -> dict:
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source.splitlines(keepends=True),
    }


cells = [
    markdown(
        """# Chipathon workshop padring -- LSTM INT8 flow

This notebook is the LSTM-specific version of the Chipathon RTL-to-GDS notebook.
It stages the fixed workshop padring, copies this repository's LSTM RTL into the
template, generates `src/chip_core.sv`, patches the GF180 SRAM macro views into
`librelane/config.yaml`, and then runs `SLOT=workshop make librelane`.

Pad map for the generated `chip_core`:

| mode | pad | signal |
|---|---|---|
| always | `input_in[0]` | `0` = host input mode, `1` = readback/output mode |
| input mode | `bidir_in[0]` | `start` |
| input mode | `bidir_in[1]` | `host_en` |
| input mode | `bidir_in[2]` | `host_we` |
| input mode | `bidir_in[9:3]` | `host_addr[6:0]` |
| input mode | `bidir_in[17:10]` | `host_wdata[7:0]` |
| readback mode | `bidir_out[0]` | `busy` |
| readback mode | `bidir_out[1]` | `done` |
| readback mode | `bidir_out[2]` | `host_rvalid` |
| readback mode | `bidir_out[10:3]` | `host_rdata[7:0]` |
| readback mode | `bidir_out[19:11]` | fixed signature/debug bits |

`timesteps` is fixed by `LSTM_TIMESTEPS` in the generated wrapper; default is
`8'd3`, matching the bundled golden testcase.
"""
    ),
    markdown("## Step 0 -- configuration"),
    code(
        r'''from pathlib import Path
import os
import shutil
import subprocess
import textwrap

# ---- flags ----
RUN_STAGE_TEMPLATE = False   # copy the workshop padring template into ~/eda/designs
RUN_CLONE_PDK      = False   # clone wafer-space GF180 PDK @ 1.8.0 into the template
RUN_STAGE_LSTM     = False   # copy LSTM RTL, generate chip_core.sv, patch SRAM macro config
RUN_FLOW           = False   # run the full RTL-to-GDS flow

# ---- container ----
CONTAINER_NAME = "gf180"

# ---- workshop padring template source ----
PADRING_REPO_URL = "https://github.com/Mauricio-xx/chipathon-2026-gf180mcu-padring.git"

DEFAULT_CODEX_GIT = (
    Path.home()
    / ".cache"
    / "codex-runtimes"
    / "codex-primary-runtime"
    / "dependencies"
    / "native"
    / "git"
    / "cmd"
    / "git.exe"
)
GIT_EXE = os.environ.get("GIT_EXE") or (str(DEFAULT_CODEX_GIT) if DEFAULT_CODEX_GIT.exists() else "git")

# ---- project paths ----
LSTM_PROJECT = Path(r"C:\personal\chipathon\rtl\lstm_int8_gf180\lstm_int8_gf180").resolve()
LSTM_WRAPPER = LSTM_PROJECT / "integration" / "chip_core_lstm.sv"

LSTM_RTL_FILES = [
    LSTM_PROJECT / "synthesis" / "gf180mcu_fd_ip_sram__sram128x8m8wm1.blackbox.v",
    LSTM_PROJECT / "rtl" / "mul8.v",
    LSTM_PROJECT / "rtl" / "act_lut.v",
    LSTM_PROJECT / "rtl" / "tanh8.v",
    LSTM_PROJECT / "rtl" / "gate_regs.v",
    LSTM_PROJECT / "rtl" / "core.v",
    LSTM_PROJECT / "rtl" / "sram_wrap.v",
    LSTM_PROJECT / "rtl" / "top.v",
]

# The original Chipathon notebook assumes it lives under examples/...
# This LSTM copy is in the LSTM repo, so either set CHIPATHON_PADRING_TEMPLATE
# or edit PADRING_TEMPLATE below to the local workshop_padring_librelane path.
try:
    NB_DIR = Path(__file__).resolve().parent
except NameError:
    NB_DIR = Path.cwd().resolve()

template_env = os.environ.get("CHIPATHON_PADRING_TEMPLATE")
TEMPLATE_CANDIDATES = [
    Path(template_env).expanduser().resolve() if template_env else None,
    (NB_DIR / ".." / ".." / "resources" / "Integration" / "workshop_padring_librelane").resolve(),
    (NB_DIR / "resources" / "Integration" / "workshop_padring_librelane").resolve(),
]
IN_REPO_TEMPLATE = next(
    (p for p in TEMPLATE_CANDIDATES
     if p and (p / "librelane" / "slots" / "slot_workshop.yaml").exists()),
    None,
)

# ---- host paths used by the Docker bind mount ----
HOST_WORKSPACE  = Path.home() / "eda" / "designs"
HOST_TEMPLATE   = HOST_WORKSPACE / "chipathon_padring" / "template"
HOST_PDK        = HOST_TEMPLATE / "gf180mcu"
HOST_LSTM_DIR   = HOST_TEMPLATE / "src" / "lstm"
CORE_PATH       = HOST_TEMPLATE / "src" / "chip_core.sv"
CONFIG_PATH     = HOST_TEMPLATE / "librelane" / "config.yaml"

# ---- container paths ----
CONTAINER_TEMPLATE = "/foss/designs/chipathon_padring/template"

# ---- PDK identifiers ----
PDK_FORK_URL  = "https://github.com/wafer-space/gf180mcu.git"
PDK_FORK_TAG  = "1.8.0"
PDK_NAME      = "gf180mcuD"
STD_CELL_LIB  = "gf180mcu_fd_sc_mcu7t5v0"


def run_or_print(cmd, do_it, *, shell_on_container=False, timeout=None):
    if shell_on_container:
        print(f"$ docker exec {CONTAINER_NAME} bash -lc '<script>'")
        print(textwrap.indent(cmd, "  | "))
    else:
        print("$ " + " ".join(str(x) for x in cmd))
    if not do_it:
        print("  (skipped -- flip the RUN_* flag to execute)\n")
        return None
    args = (
        ["docker", "exec", CONTAINER_NAME, "bash", "-lc", cmd]
        if shell_on_container else [str(x) for x in cmd]
    )
    proc = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    if proc.stdout.strip():
        print(proc.stdout[-4000:])
    if proc.returncode != 0 and proc.stderr.strip():
        print("STDERR (tail):")
        print(proc.stderr[-2000:])
    print(f"  returncode={proc.returncode}\n")
    return proc


print(f"LSTM project:          {LSTM_PROJECT}")
print(f"LSTM wrapper:          {LSTM_WRAPPER}")
print(f"Workshop template src: {IN_REPO_TEMPLATE or '(not found locally - will clone fallback repo)'}")
print(f"Git executable:        {GIT_EXE}")
print(f"Template (host):       {HOST_TEMPLATE}")
print(f"chip_core.sv path:     {CORE_PATH}")
print(f"Template (container):  {CONTAINER_TEMPLATE}")
'''
    ),
    markdown("## Step 1a -- stage the workshop padring"),
    code(
        r'''if (HOST_TEMPLATE / "librelane" / "slots" / "slot_workshop.yaml").exists():
    print(f"Template already staged at {HOST_TEMPLATE}  (skipping)")
elif RUN_STAGE_TEMPLATE:
    HOST_WORKSPACE.mkdir(parents=True, exist_ok=True)
    HOST_TEMPLATE.parent.mkdir(parents=True, exist_ok=True)
    if IN_REPO_TEMPLATE is not None:
        print(f"$ shutil.copytree({IN_REPO_TEMPLATE} -> {HOST_TEMPLATE})")
        shutil.copytree(IN_REPO_TEMPLATE, HOST_TEMPLATE, dirs_exist_ok=True)
        print(f"  staged ({sum(1 for _ in HOST_TEMPLATE.rglob('*'))} entries)\n")
    else:
        clone_template_cmd = [GIT_EXE, "clone", "--depth", "1", PADRING_REPO_URL, str(HOST_TEMPLATE)]
        run_or_print(clone_template_cmd, True, timeout=600)
else:
    if IN_REPO_TEMPLATE is not None:
        print(f"$ shutil.copytree({IN_REPO_TEMPLATE} -> {HOST_TEMPLATE})")
    else:
        print(f"$ {GIT_EXE} clone --depth 1 {PADRING_REPO_URL} {HOST_TEMPLATE}")
    print("  (skipped -- flip RUN_STAGE_TEMPLATE = True to execute)\n")
'''
    ),
    markdown("## Step 1b -- clone the wafer-space GF180 PDK fork"),
    code(
        r'''if HOST_PDK.exists():
    print(f"PDK fork already cloned at {HOST_PDK}  (skipping)")
else:
    clone_pdk_cmd = [GIT_EXE, "clone", "--depth", "1", "--branch", PDK_FORK_TAG, PDK_FORK_URL, str(HOST_PDK)]
    run_or_print(clone_pdk_cmd, RUN_CLONE_PDK, timeout=600)
'''
    ),
    markdown("## Step 2 -- stage the LSTM RTL and patch SRAM macro views"),
    code(
        r'''SRAM_MACRO = "gf180mcu_fd_ip_sram__sram128x8m8wm1"
SRAM_INSTANCE = "i_chip_core/u_lstm/u_sram_wrap/u_sram_macro"


def require_file(path):
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def patch_lstm_macro_config(config_path):
    text = config_path.read_text()
    if SRAM_MACRO not in text:
        macro_block = f"""

  {SRAM_MACRO}:
    gds:
      - dir::../gf180mcu/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/gds/{SRAM_MACRO}.gds
    lef:
      - dir::../gf180mcu/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lef/{SRAM_MACRO}.lef
    vh:
      - dir::../src/lstm/{SRAM_MACRO}.blackbox.v
    lib:
      "*":
        - dir::../gf180mcu/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/{SRAM_MACRO}__tt_025C_3v30.lib
    instances:
      "{SRAM_INSTANCE}":
        location: [1200, 1200]
        orientation: N
"""
        marker = "\n# No user macros for the workshop slot"
        if marker in text:
            text = text.replace(marker, macro_block + marker, 1)
        else:
            text = text.replace("\nPDN_MACRO_CONNECTIONS:", macro_block + "\nPDN_MACRO_CONNECTIONS:", 1)

    pdn_line = f'- "{SRAM_INSTANCE} VDD VSS VDD VSS"'
    if "PDN_MACRO_CONNECTIONS: []" in text:
        text = text.replace("PDN_MACRO_CONNECTIONS: []", "PDN_MACRO_CONNECTIONS:\n" + pdn_line, 1)
    elif pdn_line not in text:
        text = text.replace("PDN_MACRO_CONNECTIONS:\n", "PDN_MACRO_CONNECTIONS:\n" + pdn_line + "\n", 1)

    config_path.write_text(text)


for path in [LSTM_WRAPPER, *LSTM_RTL_FILES]:
    require_file(path)

if RUN_STAGE_LSTM:
    if not (HOST_TEMPLATE / "librelane" / "slots" / "slot_workshop.yaml").exists():
        raise RuntimeError("Stage the workshop template before staging the LSTM.")
    if not HOST_PDK.exists():
        raise RuntimeError("Clone/stage the GF180 PDK before patching SRAM macro views.")

    HOST_LSTM_DIR.mkdir(parents=True, exist_ok=True)
    for src in LSTM_RTL_FILES:
        dst = HOST_LSTM_DIR / src.name
        shutil.copy2(src, dst)
        print(f"copied {src.name} -> {dst}")

    include_lines = "\n".join(f'`include "lstm/{src.name}"' for src in LSTM_RTL_FILES)
    wrapper = LSTM_WRAPPER.read_text()
    generated = (
        "// Auto-generated by 03_rtl2gds_chipathon_lstm.ipynb.\n"
        "// Edit integration/chip_core_lstm.sv in the LSTM repo, then rerun this cell.\n\n"
        + include_lines
        + "\n\n"
        + wrapper
    )
    CORE_PATH.write_text(generated)
    print(f"wrote {CORE_PATH}")

    patch_lstm_macro_config(CONFIG_PATH)
    print(f"patched SRAM macro views in {CONFIG_PATH}")
else:
    print("LSTM staging preview:")
    print(f"  wrapper source: {LSTM_WRAPPER}")
    print(f"  staged RTL dir: {HOST_LSTM_DIR}")
    print(f"  generated core: {CORE_PATH}")
    print(f"  config patch:   {CONFIG_PATH}")
    print("  (skipped -- flip RUN_STAGE_LSTM = True to execute)\n")
'''
    ),
    markdown("## Step 3 -- verify staging"),
    code(
        r'''def ok(label, cond, detail=""):
    tag = "OK " if cond else "!! "
    print(f"{tag}{label}" + (f" -- {detail}" if detail else ""))
    return cond

all_ok = True
all_ok &= ok("Template dir exists", HOST_TEMPLATE.exists(), str(HOST_TEMPLATE))
all_ok &= ok("slot_workshop.yaml present", (HOST_TEMPLATE / "librelane" / "slots" / "slot_workshop.yaml").exists())
all_ok &= ok("chip_core.sv generated", CORE_PATH.exists(), str(CORE_PATH))
all_ok &= ok("LSTM RTL staged", all((HOST_LSTM_DIR / f.name).exists() for f in LSTM_RTL_FILES), str(HOST_LSTM_DIR))
all_ok &= ok("SRAM macro config patched", CONFIG_PATH.exists() and SRAM_MACRO in CONFIG_PATH.read_text())
all_ok &= ok("wafer-space PDK fork present", (HOST_PDK / "gf180mcuD").exists(), str(HOST_PDK))

proc = subprocess.run(
    ["docker", "ps", "--filter", f"name={CONTAINER_NAME}", "--format", "{{.Names}}"],
    capture_output=True,
    text=True,
)
all_ok &= ok(f"Container '{CONTAINER_NAME}' running", CONTAINER_NAME in proc.stdout)

if not all_ok:
    print("\nFix the missing items before running the flow.")
'''
    ),
    markdown("## Step 4 -- run the flow"),
    code(
        r'''flow_script = textwrap.dedent(f"""
    set -e
    cd {CONTAINER_TEMPLATE}
    source sak-pdk-script.sh {PDK_NAME} {STD_CELL_LIB}
    make librelane \\
        SLOT=workshop \\
        PDK={PDK_NAME} \\
        PDK_ROOT={CONTAINER_TEMPLATE}/gf180mcu
""").strip()

# No timeout: signoff can take hours, especially Magic/KLayout DRC.
run_or_print(flow_script, RUN_FLOW, shell_on_container=True, timeout=None)
'''
    ),
    markdown("## Step 5 -- read `metrics.csv`"),
    code(
        r'''import csv

metrics_path = HOST_TEMPLATE / "final" / "metrics.csv"
wanted = [
    "design__die__area__um2",
    "design__instance__count",
    "design__instance__count__stdcell",
    "design__instance__count__class:macro",
    "magic__drc_error__count",
    "klayout__drc_error__count",
    "design__lvs_error__count",
    "antenna__violating__nets",
    "timing__setup_vio__count",
    "timing__hold_vio__count",
    "power__total",
]

if not metrics_path.exists():
    print(f"metrics.csv not found: {metrics_path}")
    print("Did Step 4 complete? Set RUN_FLOW = True and rerun.")
else:
    found = {}
    with metrics_path.open() as fh:
        for row in csv.reader(fh):
            if row and row[0] in wanted:
                found[row[0]] = row[1] if len(row) > 1 else ""
    for k in wanted:
        print(f"  {k:45s} {found.get(k, '(missing)')}")
'''
    ),
    markdown("## Step 6 -- show the render"),
    code(
        r'''from IPython.display import Image, display

png_path = HOST_TEMPLATE / "final" / "render" / "chip_top.png"
gds_path = HOST_TEMPLATE / "final" / "gds" / "chip_top.gds"

if png_path.exists():
    print(f"Render: {png_path}")
    display(Image(str(png_path)))
else:
    print(f"No render PNG yet at {png_path}")
    if gds_path.exists():
        print(f"GDS is there: {gds_path}")
        print(f"  open on the host: klayout {gds_path}")
'''
    ),
]

notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "pygments_lexer": "ipython3"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}

OUT.write_text(json.dumps(notebook, indent=1))
print(OUT)
