`timescale 1ns/1ps

// Core FSM for one-state INT8 LSTM cell.
// Gate order in SRAM and control flow: f, i, g, o.
// Each SRAM byte stores one signed INT8 value.
module lstm_core #(
    parameter integer ACC_WIDTH        = 24,
    parameter integer FRAC_BITS        = 7,
    parameter integer GATE_INPUT_SHIFT = 10,

    parameter [6:0] W_BASE   = 7'd0,    // 36 bytes: f,i,g,o weights, 9 each
    parameter [6:0] B_BASE   = 7'd40,   // 4 bytes: f,i,g,o bias
    parameter [6:0] X_BASE   = 7'd48,   // inputs: 8 bytes per timestep, up to 4 timesteps
    parameter [6:0] H0_ADDR  = 7'd88,
    parameter [6:0] C0_ADDR  = 7'd89,
    parameter [6:0] OH_BASE  = 7'd96,
    parameter [6:0] OC_BASE  = 7'd104,
    parameter [6:0] SIG_ADDR = 7'd127,
    parameter [3:0] MAX_T    = 4'd4
)(
    input  wire       clk,
    input  wire       rst_n,

    input  wire       start,
    input  wire [7:0] timesteps,
    output reg        busy,
    output reg        done,

    output reg        sram_en,
    output reg        sram_we,
    output reg [6:0]  sram_addr,
    output reg [7:0]  sram_wdata,
    input  wire [7:0] sram_rdata
);
    // Gate order: f, i, g, o.
    localparam [1:0] GATE_F = 2'd0;
    localparam [1:0] GATE_I = 2'd1;
    localparam [1:0] GATE_G = 2'd2;
    localparam [1:0] GATE_O = 2'd3;

    localparam [4:0]
        ST_IDLE            = 5'd0,
        ST_READ_H_REQ      = 5'd1,
        ST_READ_H_CAP      = 5'd2,
        ST_READ_C_REQ      = 5'd3,
        ST_READ_C_CAP      = 5'd4,
        ST_READ_X_REQ      = 5'd5,
        ST_READ_X_CAP      = 5'd6,
        ST_GATE_BIAS_REQ   = 5'd7,
        ST_GATE_BIAS_CAP   = 5'd8,
        ST_GATE_WEIGHT_REQ = 5'd9,
        ST_GATE_MAC        = 5'd10,
        ST_SAVE_GATE       = 5'd11,
        ST_MUL_FC          = 5'd12,
        ST_MUL_IG          = 5'd13,
        ST_UPDATE_C        = 5'd14,
        ST_MUL_OH          = 5'd15,
        ST_UPDATE_H        = 5'd16,
        ST_WRITE_H         = 5'd17,
        ST_WRITE_C         = 5'd18,
        ST_NEXT_T          = 5'd19,
        ST_WRITE_SIG       = 5'd20,
        ST_DONE            = 5'd21;

    reg [4:0] state;

    reg [3:0] timestep_index;
    reg [3:0] timestep_total;
    reg [1:0] current_gate;
    reg [3:0] vector_index;  // 0..8: y0..y7,h
    reg [2:0] input_index;   // 0..7: y0..y7

    // Current input vector y = [y0..y7].
    reg signed [7:0] y0;
    reg signed [7:0] y1;
    reg signed [7:0] y2;
    reg signed [7:0] y3;
    reg signed [7:0] y4;
    reg signed [7:0] y5;
    reg signed [7:0] y6;
    reg signed [7:0] y7;

    // One hidden state and one cell state.
    reg signed [7:0] h_state;
    reg signed [7:0] c_state;
    reg signed [7:0] c_next;

    // Dot-product accumulator and state-update terms.
    reg signed [ACC_WIDTH-1:0] acc;
    reg signed [ACC_WIDTH-1:0] fc_product_ext;
    reg signed [ACC_WIDTH-1:0] ig_product_ext;
    reg signed [ACC_WIDTH-1:0] oh_product_ext;

    // Four gates: f, i, g, o.
    wire signed [7:0] gate_f;
    wire signed [7:0] gate_i;
    wire signed [7:0] gate_g;
    wire signed [7:0] gate_o;

    wire gate_clear;
    wire gate_write_en;
    wire signed [7:0] gate_value_from_activation;
    wire signed [7:0] gate_value_from_lut;

    assign gate_clear    = (state == ST_IDLE) && start;
    assign gate_write_en = (state == ST_SAVE_GATE);

    gate_regs u_gate_regs (
        .clk         (clk),
        .rst_n       (rst_n),
        .clear       (gate_clear),
        .write_en    (gate_write_en),
        .gate_select (current_gate),
        .gate_value  (gate_value_from_activation),
        .gate_f      (gate_f),
        .gate_i      (gate_i),
        .gate_g      (gate_g),
        .gate_o      (gate_o)
    );

    // One small combinational multiplier reused by the FSM.
    reg  signed [7:0]  mul_a;
    reg  signed [7:0]  mul_b;
    wire signed [15:0] mul_product;

    mul8 u_mul8 (
        .a       (mul_a),
        .b       (mul_b),
        .product (mul_product)
    );

    // All gates use the same 32-entry LUT shape over [-1, 1):
    // tanh for g, sigmoid for f/i/o.
    act_lut #(
        .ACC_WIDTH   (ACC_WIDTH),
        .INPUT_SHIFT (GATE_INPUT_SHIFT)
    ) u_gate_activation (
        .acc     (acc),
        .is_tanh (current_gate == GATE_G),
        .value   (gate_value_from_lut)
    );

    assign gate_value_from_activation = gate_value_from_lut;

    // tanh(c_next) used when computing h_next = o * tanh(c_next).
    wire signed [7:0] tanh_c_next;

    tanh8 u_tanh_c (
        .x (c_next),
        .y (tanh_c_next)
    );

    function signed [7:0] byte_to_s8;
        input [7:0] byte_value;
        begin
            byte_to_s8 = byte_value;
        end
    endfunction

    function [7:0] s8_to_byte;
        input signed [7:0] value;
        begin
            s8_to_byte = value[7:0];
        end
    endfunction

    function signed [ACC_WIDTH-1:0] product_to_acc;
        input signed [15:0] product;
        begin
            product_to_acc = {{(ACC_WIDTH-16){product[15]}}, product};
        end
    endfunction

    function signed [7:0] vector_value;
        input [3:0] index;
        begin
            case (index)
                4'd0: vector_value = y0;
                4'd1: vector_value = y1;
                4'd2: vector_value = y2;
                4'd3: vector_value = y3;
                4'd4: vector_value = y4;
                4'd5: vector_value = y5;
                4'd6: vector_value = y6;
                4'd7: vector_value = y7;
                default: vector_value = h_state;
            endcase
        end
    endfunction

    function signed [7:0] sat8;
        input signed [ACC_WIDTH-1:0] value;
        begin
            if (value > 127)
                sat8 = 8'sd127;
            else if (value < -128)
                sat8 = 8'sh80;
            else
                sat8 = value[7:0];
        end
    endfunction

    function [6:0] weight_addr;
        input [1:0] gate_id;
        input [3:0] index;
        reg [6:0] gate_as_7;
        begin
            gate_as_7 = {5'd0, gate_id};
            weight_addr = W_BASE + (gate_as_7 << 3) + gate_as_7 + {3'd0, index}; // gate*9 + index
        end
    endfunction

    function [6:0] input_addr;
        input [3:0] timestep;
        input [2:0] index;
        begin
            input_addr = X_BASE + ({3'd0, timestep} << 3) + {4'd0, index}; // timestep*8 + index
        end
    endfunction

    function [3:0] clamp_timesteps;
        input [7:0] requested;
        begin
            if (requested == 8'd0)
                clamp_timesteps = 4'd1;
            else if (requested > {4'd0, MAX_T})
                clamp_timesteps = MAX_T;
            else
                clamp_timesteps = requested[3:0];
        end
    endfunction

    // SRAM access control. Read states use request/capture pairs.
    always @(*) begin
        sram_en    = 1'b0;
        sram_we    = 1'b0;
        sram_addr  = 7'd0;
        sram_wdata = 8'd0;

        case (state)
            ST_READ_H_REQ: begin
                sram_en   = 1'b1;
                sram_addr = H0_ADDR;
            end

            ST_READ_C_REQ: begin
                sram_en   = 1'b1;
                sram_addr = C0_ADDR;
            end

            ST_READ_X_REQ: begin
                sram_en   = 1'b1;
                sram_addr = input_addr(timestep_index, input_index);
            end

            ST_GATE_BIAS_REQ: begin
                sram_en   = 1'b1;
                sram_addr = B_BASE + {5'd0, current_gate};
            end

            ST_GATE_WEIGHT_REQ: begin
                sram_en   = 1'b1;
                sram_addr = weight_addr(current_gate, vector_index);
            end

            ST_WRITE_H: begin
                sram_en    = 1'b1;
                sram_we    = 1'b1;
                sram_addr  = OH_BASE + {3'd0, timestep_index};
                sram_wdata = s8_to_byte(h_state);
            end

            ST_WRITE_C: begin
                sram_en    = 1'b1;
                sram_we    = 1'b1;
                sram_addr  = OC_BASE + {3'd0, timestep_index};
                sram_wdata = s8_to_byte(c_state);
            end

            ST_WRITE_SIG: begin
                sram_en    = 1'b1;
                sram_we    = 1'b1;
                sram_addr  = SIG_ADDR;
                sram_wdata = 8'hA5 ^ h_state ^ c_state;
            end

            default: begin
                sram_en    = 1'b0;
                sram_we    = 1'b0;
                sram_addr  = 7'd0;
                sram_wdata = 8'd0;
            end
        endcase
    end

    // Multiplier input selection. Only one mul8 instance is used.
    always @(*) begin
        mul_a = 8'sd0;
        mul_b = 8'sd0;

        case (state)
            // Gate dot product: weight[k] * vector[k].
            ST_GATE_MAC: begin
                mul_a = byte_to_s8(sram_rdata);
                mul_b = vector_value(vector_index);
            end

            // c_next first term: f * c_old.
            ST_MUL_FC: begin
                mul_a = gate_f;
                mul_b = c_state;
            end

            // c_next second term: i * g.
            ST_MUL_IG: begin
                mul_a = gate_i;
                mul_b = gate_g;
            end

            // h_next term: o * tanh(c_next).
            ST_MUL_OH: begin
                mul_a = gate_o;
                mul_b = tanh_c_next;
            end

            default: begin
                mul_a = 8'sd0;
                mul_b = 8'sd0;
            end
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state            <= ST_IDLE;
            busy             <= 1'b0;
            done             <= 1'b0;
            timestep_index   <= 4'd0;
            timestep_total   <= 4'd1;
            current_gate     <= GATE_F;
            vector_index     <= 4'd0;
            input_index      <= 3'd0;
            y0               <= 8'sd0;
            y1               <= 8'sd0;
            y2               <= 8'sd0;
            y3               <= 8'sd0;
            y4               <= 8'sd0;
            y5               <= 8'sd0;
            y6               <= 8'sd0;
            y7               <= 8'sd0;
            h_state          <= 8'sd0;
            c_state          <= 8'sd0;
            c_next           <= 8'sd0;
            acc              <= {ACC_WIDTH{1'b0}};
            fc_product_ext   <= {ACC_WIDTH{1'b0}};
            ig_product_ext   <= {ACC_WIDTH{1'b0}};
            oh_product_ext   <= {ACC_WIDTH{1'b0}};
        end else begin
            done <= 1'b0;
            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy           <= 1'b1;
                        done           <= 1'b0;
                        timestep_index <= 4'd0;
                        timestep_total <= clamp_timesteps(timesteps);
                        state          <= ST_READ_H_REQ;
                    end
                end

                ST_READ_H_REQ: begin
                    state <= ST_READ_H_CAP;
                end

                ST_READ_H_CAP: begin
                    h_state <= byte_to_s8(sram_rdata);
                    state   <= ST_READ_C_REQ;
                end

                ST_READ_C_REQ: begin
                    state <= ST_READ_C_CAP;
                end

                ST_READ_C_CAP: begin
                    c_state     <= byte_to_s8(sram_rdata);
                    input_index <= 3'd0;
                    state       <= ST_READ_X_REQ;
                end

                ST_READ_X_REQ: begin
                    state <= ST_READ_X_CAP;
                end

                ST_READ_X_CAP: begin
                    case (input_index)
                        3'd0: y0 <= byte_to_s8(sram_rdata);
                        3'd1: y1 <= byte_to_s8(sram_rdata);
                        3'd2: y2 <= byte_to_s8(sram_rdata);
                        3'd3: y3 <= byte_to_s8(sram_rdata);
                        3'd4: y4 <= byte_to_s8(sram_rdata);
                        3'd5: y5 <= byte_to_s8(sram_rdata);
                        3'd6: y6 <= byte_to_s8(sram_rdata);
                        default: y7 <= byte_to_s8(sram_rdata);
                    endcase

                    if (input_index == 3'd7) begin
                        current_gate <= GATE_F;
                        state        <= ST_GATE_BIAS_REQ;
                    end else begin
                        input_index <= input_index + 3'd1;
                        state       <= ST_READ_X_REQ;
                    end
                end

                // Start one gate: acc = bias << BIAS_SHIFT.
                ST_GATE_BIAS_REQ: begin
                    state <= ST_GATE_BIAS_CAP;
                end

                ST_GATE_BIAS_CAP: begin
                    acc <= {{(ACC_WIDTH-8){sram_rdata[7]}}, sram_rdata} <<< FRAC_BITS;
                    vector_index <= 4'd0;
                    state <= ST_GATE_WEIGHT_REQ;
                end

                // Accumulate one term: acc += weight[k] * vector[k].
                ST_GATE_WEIGHT_REQ: begin
                    state <= ST_GATE_MAC;
                end

                ST_GATE_MAC: begin
                    acc <= acc + product_to_acc(mul_product);

                    if (vector_index == 4'd8) begin
                        state <= ST_SAVE_GATE;
                    end else begin
                        vector_index <= vector_index + 4'd1;
                        state <= ST_GATE_WEIGHT_REQ;
                    end
                end

                // Store one gate output after activation LUT.
                ST_SAVE_GATE: begin
                    if (current_gate == GATE_O) begin
                        state <= ST_MUL_FC;
                    end else begin
                        current_gate <= current_gate + 2'd1;
                        state <= ST_GATE_BIAS_REQ;
                    end
                end

                // Clear state update sequence:
                //   1) fc_product_ext = f * c_old
                //   2) ig_product_ext = i * g
                //   3) c_next = sat8((f*c_old >> STATE_SHIFT) + (i*g >> STATE_SHIFT))
                //   4) h_next = sat8((o*tanh(c_next)) >> STATE_SHIFT)
                ST_MUL_FC: begin
                    fc_product_ext <= product_to_acc(mul_product);
                    state <= ST_MUL_IG;
                end

                ST_MUL_IG: begin
                    ig_product_ext <= product_to_acc(mul_product);
                    state <= ST_UPDATE_C;
                end

                ST_UPDATE_C: begin
                    c_next <= sat8((fc_product_ext >>> FRAC_BITS) +
                                   (ig_product_ext >>> FRAC_BITS));
                    state <= ST_MUL_OH;
                end

                ST_MUL_OH: begin
                    oh_product_ext <= product_to_acc(mul_product);
                    state <= ST_UPDATE_H;
                end

                ST_UPDATE_H: begin
                    h_state <= sat8(oh_product_ext >>> FRAC_BITS);
                    c_state <= c_next;
                    state   <= ST_WRITE_H;
                end

                ST_WRITE_H: begin
                    state <= ST_WRITE_C;
                end

                ST_WRITE_C: begin
                    state <= ST_NEXT_T;
                end

                ST_NEXT_T: begin
                    if (timestep_index + 4'd1 >= timestep_total) begin
                        state <= ST_WRITE_SIG;
                    end else begin
                        timestep_index <= timestep_index + 4'd1;
                        input_index <= 3'd0;
                        state <= ST_READ_X_REQ;
                    end
                end

                ST_WRITE_SIG: begin
                    state <= ST_DONE;
                end

                ST_DONE: begin
                    busy  <= 1'b0;
                    done  <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
endmodule
