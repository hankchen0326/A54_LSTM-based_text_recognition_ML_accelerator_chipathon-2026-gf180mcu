`timescale 1ns/1ps

// Top-level wrapper for the GF180 Chipathon LSTM MVP.
// This file stays small: it connects host, core, and SRAM.
module lstm_top #(
    parameter integer ACC_WIDTH        = 24,
    parameter integer FRAC_BITS        = 7,
    parameter integer GATE_INPUT_SHIFT = 10,

    parameter [6:0] W_BASE   = 7'd0,
    parameter [6:0] B_BASE   = 7'd40,
    parameter [6:0] X_BASE   = 7'd48,
    parameter [6:0] H0_ADDR  = 7'd88,
    parameter [6:0] C0_ADDR  = 7'd89,
    parameter [6:0] OH_BASE  = 7'd96,
    parameter [6:0] OC_BASE  = 7'd104,
    parameter [6:0] SIG_ADDR = 7'd127,
    parameter [3:0] MAX_T    = 4'd4
)(
    input  wire       clk,
    input  wire       rst_n,

    input  wire       start,
    input  wire [7:0] timesteps,
    output wire       busy,
    output wire       done,

    // Host can access SRAM when busy=0.
    input  wire       host_en,
    input  wire       host_we,
    input  wire [6:0] host_addr,
    input  wire [7:0] host_wdata,
    output wire [7:0] host_rdata,
    output wire       host_rvalid,

    inout  wire       VDD,
    inout  wire       VSS
);
    wire        core_sram_en;
    wire        core_sram_we;
    wire [6:0]  core_sram_addr;
    wire [7:0]  core_sram_wdata;

    wire        sram_en;
    wire        sram_we;
    wire [6:0]  sram_addr;
    wire [7:0]  sram_wdata;
    wire [7:0]  sram_rdata;
    reg         host_rvalid_r;

    // SRAM ownership mux.
    // busy=0: host owns SRAM.
    // busy=1: LSTM core owns SRAM.
    assign sram_en    = busy ? core_sram_en    : host_en;
    assign sram_we    = busy ? core_sram_we    : (host_en && host_we);
    assign sram_addr  = busy ? core_sram_addr  : host_addr;
    assign sram_wdata = busy ? core_sram_wdata : host_wdata;
    assign host_rdata = sram_rdata;
    assign host_rvalid = host_rvalid_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            host_rvalid_r <= 1'b0;
        else
            host_rvalid_r <= (!busy) && host_en && (!host_we);
    end

    lstm_core #(
        .ACC_WIDTH        (ACC_WIDTH),
        .FRAC_BITS        (FRAC_BITS),
        .GATE_INPUT_SHIFT (GATE_INPUT_SHIFT),
        .W_BASE           (W_BASE),
        .B_BASE           (B_BASE),
        .X_BASE           (X_BASE),
        .H0_ADDR          (H0_ADDR),
        .C0_ADDR          (C0_ADDR),
        .OH_BASE          (OH_BASE),
        .OC_BASE          (OC_BASE),
        .SIG_ADDR         (SIG_ADDR),
        .MAX_T            (MAX_T)
    ) u_core (
        .clk         (clk),
        .rst_n       (rst_n),
        .start       (start),
        .timesteps   (timesteps),
        .busy        (busy),
        .done        (done),
        .sram_en     (core_sram_en),
        .sram_we     (core_sram_we),
        .sram_addr   (core_sram_addr),
        .sram_wdata  (core_sram_wdata),
        .sram_rdata  (sram_rdata)
    );

    sram_wrap u_sram_wrap (
        .clk   (clk),
        .en    (sram_en),
        .we    (sram_we),
        .addr  (sram_addr),
        .wdata (sram_wdata),
        .rdata (sram_rdata),
        .VDD   (VDD),
        .VSS   (VSS)
    );
endmodule
