`timescale 1ns/1ps

// Wrapper around the GF180 128x8 SRAM macro.
// The wrapper exposes simple active-high en/we signals.
module sram_wrap (
    input  wire       clk,
    input  wire       en,
    input  wire       we,
    input  wire [6:0] addr,
    input  wire [7:0] wdata,
    output wire [7:0] rdata,
    inout  wire       VDD,
    inout  wire       VSS
);
    wire       sram_cen;
    wire       sram_gwen;
    wire [7:0] sram_wen;
    wire       sram_clk;

    assign sram_cen  = ~en;                 // active-low chip enable
    assign sram_gwen = ~we;                 // active-low global write enable
    assign sram_wen  = we ? 8'h00 : 8'hFF; // active-low bit write mask

`ifndef SYNTHESIS
    // The foundry simulation model checks SRAM timing against its own clock.
    // Delay the macro clock slightly so address/control from the RTL FSM have
    // time to settle before the macro samples them.
    assign #15 sram_clk = clk;
`else
    assign sram_clk = clk;
`endif

    gf180mcu_fd_ip_sram__sram128x8m8wm1 u_sram_macro (
        .CLK  (sram_clk),
        .CEN  (sram_cen),
        .GWEN (sram_gwen),
        .WEN  (sram_wen),
        .A    (addr),
        .D    (wdata),
        .Q    (rdata),
        .VDD  (VDD),
        .VSS  (VSS)
    );
endmodule
