Vectors Folder Guide
====================

This folder stores the generated test inputs and golden reference traces used
by the simulation testbench.

Files
-----

testcase_init.hex
    Initial SRAM image written by the testbench before starting the LSTM core.
    This includes weights, biases, input sequence data, h0, and c0.
    It is a full 128-byte memory image, so it has many more entries than the
    step-by-step trace files.

trace_acc_q214.hex
    Golden MAC accumulator results for each gate.
    One line per gate evaluation.
    Width: 24-bit signed value, stored as 6 hex digits per line.
    Count in current testcase: timesteps * 4 gates = 3 * 4 = 12 lines.

trace_gate_q17.hex
    Golden gate outputs after activation lookup.
    Order per timestep: f, i, g, o.
    Width: 8-bit signed Q1.7.
    Count in current testcase: timesteps * 4 gates = 12 lines.

trace_c_next_q17.hex
    Golden c_next result for each timestep.
    Width: 8-bit signed Q1.7.
    Count in current testcase: timesteps = 3 lines.

trace_h_next_q17.hex
    Golden h_next result for each timestep.
    Width: 8-bit signed Q1.7.
    Count in current testcase: timesteps = 3 lines.

testcase_summary.json
    Human-readable summary of the testcase.
    Includes both:
      - *_q17    quantized signed integer values
      - *_float  dequantized values (integer divided by 128)
    Also includes timestep-by-timestep trace details.

Why The File Lengths Differ
---------------------------

Not every file stores the same kind of data:

    - gate/acc traces: 4 values per timestep (f, i, g, o)
    - c_next trace:    1 value per timestep
    - h_next trace:    1 value per timestep
    - init image:      full SRAM contents

For the current testcase with 3 timesteps:

    trace_acc_q214.hex   -> 12 values
    trace_gate_q17.hex   -> 12 values
    trace_c_next_q17.hex -> 3 values
    trace_h_next_q17.hex -> 3 values
    testcase_init.hex    -> 128 SRAM bytes

How To Read Q1.7 Data
---------------------

Q1.7 means the stored signed integer represents:

    real_value = signed_integer / 128

Examples:

    40  -> 0x40 ->  64 ->  64 / 128 =  0.5
    30  -> 0x30 ->  48 ->  48 / 128 =  0.375
    e7  -> 0xE7 -> -25 -> -25 / 128 = -0.1953125
    f4  -> 0xF4 -> -12 -> -12 / 128 = -0.09375

Note:
    Q1.7 values are stored as normal 8-bit signed two's-complement bytes.
    The divide-by-128 is the fixed-point interpretation.

How To Read trace_acc_q214.hex
------------------------------

This file is different from the Q1.7 files.

It stores the wider accumulator used inside the MAC loop.
Each line is a signed 24-bit value written in hex.

Examples:

    0011c0 -> positive 24-bit integer
    ffff5c -> negative 24-bit two's-complement integer

This file is wider because the MAC accumulator must hold multiple products
without overflowing.

Current Trace Ordering
----------------------

For trace_gate_q17.hex and trace_acc_q214.hex:

    timestep 0: f, i, g, o
    timestep 1: f, i, g, o
    timestep 2: f, i, g, o

For trace_c_next_q17.hex and trace_h_next_q17.hex:

    line 1 -> timestep 0
    line 2 -> timestep 1
    line 3 -> timestep 2

Regenerating These Files
------------------------

From the project root:

    C:\Users\new12\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe scripts\gen_golden_case.py

